HC12T1: Print a Welcome Message

```haskell
main :: IO ()
main = putStrLn "Welcome to Haskell Programming!"
```
